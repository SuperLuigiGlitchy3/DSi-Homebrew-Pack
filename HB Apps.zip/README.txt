You can put the folder directly everywhere on your SD Card. Have fun!
