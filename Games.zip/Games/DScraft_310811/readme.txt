DScraft v310811
www.smealum.net/dscraft

Changelog :
- added ladders and doors
- added new dynamic lighting to make caves darker
- added underwater effect
- added control scheme 3 (doesn't require shoulder buttons)
- added mc2ds, a Minecraft to DScraft world converter
- added mapUpdate, a program to recalculate some lighting values to work better with 310811
- included new default worlds
- made it easier to get out of water (again)
- fixed torch placing related bugs
- fixed quad cache overflow bug
- fixed inventory-opening crash
- fixed moon
- fixed menu glitch
- fixed edge related bugs
- many other various bugfixes

/!\ IMPORTANT /!\ : included in this version is a program named mapUpdate. This program is designed to update worlds made with previous versions of the game to work better on 310811. (it will mostly fix trees) Simply drag and drop you map file on mapUpdate.exe and let it work for a second; it should create a brand new testmap.map file.

1. Install instructions

Simply drag and drop DScraft.nds and the dscraft directory to your card. (NO NEED to transfer the separate worlds directory)
IMPORTANT - if using nitroFS version, dscraft folder MUST BE in the same directory as DScraft.nds.
if using FAT version, dscraft folder MUST BE placed at the root of the card.

Included are a "worlds" directory and a program named mapGen. The worlds directory contains several pre-generated worlds for you to explore; simply drag and drop the files to the dscraft/worlds directory to install each one.
The mapGen program is used to generate new worlds. Simply execute it and follow the steps.

New worlds can be installed by copying .map files to the dscraft/worlds directory.
Texture packs can be installed by unzipping them in a directory in the dscraft/packs folder.
Screenshots are stored in the dscraft/screens directory.

2. Controls

See in game options menu;
For control scheme 1, jumping is done by double tapping the touch screen.
Start exits the game.

3. Troubleshooting

First : if the nitroFS version doesn't work, try the FAT version. 
Second : If the FAT version doesn't work, make sure you copied the ENTIRE dscraft directory to your card and that it is in the SAME directory as the DScraft.nds file.

If all else fails, you can seek help on the GBAtemp.net thread for the game : http://gbatemp.net/t300847-minecraft-ds-in-3d?

Have fun ! 