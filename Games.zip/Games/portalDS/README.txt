--------------------------
- Aperture Science DS r1 -
--------------------------
by smealum and lobo
http://smealum.net/ASDS/
smealum@gmail.com


_DESCRIPTION_

This game is an adaptation of the portal games for the nintendo DS. It includes most of the mechanics found in the original. The code was written entirely by smealum (http://smealum.net, twitter.com/smealum) and the graphics were all made by Lobo (http://infectuous.com, twitter/infectuous).
This version is the first public release. It is very buggy and incomplete, but it is mostly playable. It includes 14 levels made by smealum, loganino and tenteran. It also features a full-fledged on-board level editor inspired by portal 2's own perpetual testing initiative.
The game also features a kick-ass though largely incomplete and unpolished menu.

_INSTALLATION INSTRUCTIONS_

This game requires nitroFS. If your flashcart's menu does not support nitroFS (some menus that do include Wood R4 and the supercard DStwo's menu), please download hbmenu (http://devkitpro.org/wiki/Homebrew_Menu) and use it to run the game.
The included asds folder should be placed in the same directory as the nds file. The folder will however be created automatically if it is not found.

In order to add new maps to your game, just place the .map files in the asds/maps folder.

_GAME CONTROLS_

Default control scheme :
	DPAD/ABXY : move
	TOUCHSCREEN : aim
	R/L : shoot/grab items/activate timed buttons
	START : pause

Controls are fully customizable via the config.ini file found in the asds folder. Take a look at the included one for more information and an already prepared no-touch control scheme.

_EDITOR CONTROLS_

	DPAD/ABXY : move/look around
	START : save
	TOUCH : select stuff (objects, or planar block selection, or 3D block selection)
		use contextual buttons for actions related to what you've selected (make stuf (un)portalable, fill/delete, add sludge...)
		pull/push blocks to create level geometry

Basically it's a highly bastardized version of the portal 2 level editor. If in doubt you might want to check out the video I made a couple months ago : http://www.youtube.com/watch?v=frfbSgE7pPI
Or just ask me.
It will soon be possible to share levels on http://smealum.net/ASDS/ ! Not yet however. In the meantime, don't hesitate to upload them and post them in the forum threads dedicated to the game.